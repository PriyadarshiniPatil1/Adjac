Simple HTTP server for Ninja qPCR browser app.

node server.js

curl -d @demo_param.json -H "Content-Type: application/json" http://localhost:2222/protocols/704D8607-5040-4B07-8401-7F90E8B855C4/update
