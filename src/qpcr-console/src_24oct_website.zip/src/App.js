import React from 'react'

import Sartupwizard from "./components/Navbar/Sartupwizard"
function App() {
  return (
    <div>
      
      <Sartupwizard/>
    </div>
  )
}

export default App
